#include <Arduino.h>

// Opcodes (exactly as in main(3).cpp):
// SRAM0:0, SRAM1:1, RESET0:2, RESET1:3, FTW0:4, FTW1:5, RUN:7
enum : uint8_t {
  OP_SRAM0  = 0b000,
  OP_SRAM1  = 0b001,
  OP_RESET0 = 0b010,
  OP_RESET1 = 0b011,
  OP_FTW0   = 0b100,
  OP_FTW1   = 0b101,
  OP_RUN    = 0b111,
};

static int PIN_SCK  = -1;
static int PIN_MOSI = -1;
static int PIN_CS   = -1;
static int PIN_RSTN = -1;   // hardware reset pin (active-low)

static inline void clk_delay() { delayMicroseconds(1); }
static inline void cs_low()  { digitalWrite(PIN_CS, LOW); }
static inline void cs_high() { digitalWrite(PIN_CS, HIGH); }

// EXACT match to his sendBits():
// if (num >= 2^i) num -= 2^i and output 1 else 0.
static inline void sendBits(int len, uint32_t num) {
  for (int i = len - 1; i >= 0; --i) {
    uint32_t pow2 = (1u << i);
    if (num >= pow2) {
      num -= pow2;
      digitalWrite(PIN_MOSI, HIGH);
    } else {
      digitalWrite(PIN_MOSI, LOW);
    }
    digitalWrite(PIN_SCK, HIGH);
    //clk_delay();
    digitalWrite(PIN_SCK, LOW);
    //clk_delay();
  }
}

// Bit-banged SPI init (hz unused)
extern "C" void fpga_spi_setup(int sck, int mosi, int cs, unsigned hz_unused) {
  (void)hz_unused;

  PIN_SCK  = sck;
  PIN_MOSI = mosi;
  PIN_CS   = cs;

  pinMode(PIN_SCK, OUTPUT);
  pinMode(PIN_MOSI, OUTPUT);
  pinMode(PIN_CS, OUTPUT);

  // His setup drives these low before releasing reset.
  digitalWrite(PIN_SCK, LOW);
  digitalWrite(PIN_MOSI, LOW);
  digitalWrite(PIN_CS, LOW);

  Serial.printf("[SPI] FPGA-guy 35-bit bitbang SCK=%d MOSI=%d CS=%d\n", sck, mosi, cs);
}

// Hardware reset pin support (exactly his setup behavior)
extern "C" void fpga_reset_setup(int rstn_pin) {
  PIN_RSTN = rstn_pin;
  pinMode(PIN_RSTN, OUTPUT);
  digitalWrite(PIN_RSTN, HIGH); // deassert
  Serial.printf("[SPI] rstn pin=%d (active-low)\n", rstn_pin);
}

extern "C" void fpga_reset_pulse() {
  if (PIN_RSTN < 0) return;

  digitalWrite(PIN_RSTN, LOW);
  digitalWrite(PIN_SCK, LOW);
  digitalWrite(PIN_MOSI, LOW);
  digitalWrite(PIN_CS, LOW);
  delayMicroseconds(1);
  digitalWrite(PIN_RSTN, HIGH);
}

// 35-bit frame writers
extern "C" void fpga_write_sram(uint8_t bank, uint16_t addr, uint16_t data) {
  const uint8_t op = (bank & 1) ? OP_SRAM1 : OP_SRAM0;

  cs_low();
  sendBits(3, op);
  sendBits(16, addr);
  sendBits(16, data);
  cs_high();
}

extern "C" void fpga_set_reset_width(uint8_t nco, uint32_t reset_val) {
  const uint8_t op = (nco & 1) ? OP_RESET1 : OP_RESET0;

  cs_low();
  sendBits(3, op);
  sendBits(16, reset_val-1);  // IMPORTANT: keep as 32-bit into sendBits(16, ...) to match his overflow behavior
  sendBits(16, 0);
  cs_high();
}

extern "C" void fpga_set_ftw(uint8_t nco, uint32_t tuningWord) {
  const uint8_t op = (nco & 1) ? OP_FTW1 : OP_FTW0;

  cs_low();
  sendBits(3, op);
  sendBits(16, tuningWord >> 16);
  sendBits(16, tuningWord % (1u << 16));
  cs_high();
}

extern "C" void fpga_run() {
  cs_low();
  sendBits(3, OP_RUN);
  sendBits(16, 0);
  sendBits(16, 0);
  cs_high();
}
