// wavegen.cpp
// FPGA-guy register algorithm (reset/ftw rules + RUN) + amp/offset/phase LUT synthesis
// ARB updated: resample 1024 -> width (NOT 64k) so ARB matches STD high-freq behavior.

#include <Arduino.h>
#include <math.h>
#include <stdint.h>

extern "C" {
  void fpga_write_sram(uint8_t bank, uint16_t addr, uint16_t data);
  void fpga_set_ftw(uint8_t nco_index, uint32_t ftw);
  void fpga_set_reset_width(uint8_t nco_index, uint16_t reset);
  void fpga_run();
}

// MUST match ble.cpp layout exactly:
// shape, freq_mHz, amp_mVpp, offset_mV, phase_deg, channel
struct StdParams {
  uint8_t  shape;       // 0=sine, 1=square, 2=triangle, 3=sinc
  uint32_t freq_mHz;    // milli-Hz
  uint32_t amp_mVpp;    // mVpp
  int32_t  offset_mV;   // mV
  int16_t  phase_deg;   // degrees
  uint8_t  channel;     // 0=A, 1=B
};

static constexpr uint32_t LUT_SIZE_MAX = 65536;
static constexpr uint32_t ARB_IN_SAMPLES = 1024;

static volatile bool tx_busy = false;

static inline const char* chan_name(uint8_t ch){ return (ch & 1) ? "B" : "A"; }

// ---- normalized waveform primitives (-1..+1) ----
static inline double w_sine(double ph) { return sin(2.0 * M_PI * ph); }

static inline double w_square(double ph) {
  double t = ph - floor(ph);
  return (t < 0.5) ? 1.0 : -1.0;
}

static inline double w_triangle(double ph) {
  double t = ph - floor(ph);
  if (t < 0.25)      return 4.0 * t;
  else if (t < 0.75) return 2.0 - 4.0 * t;
  else               return -4.0 + 4.0 * t;
}

static inline double w_sinc(double ph) {
  const double L = 6.0;
  double x = (ph - 0.5) * L;
  if (fabs(x) < 1e-12) return 1.0;
  double pix = M_PI * x;
  return sin(pix) / pix;
}

// Map voltage into DAC code (0..65535) assuming +/-5V range at DAC
static inline uint16_t v_to_code(double v) {
  double code = (v + 5.0) * (65535.0 / 10.0);
  if (code < 0.0) code = 0.0;
  if (code > 65535.0) code = 65535.0;
  return (uint16_t)(code + 0.5);
}

static inline uint16_t sample_code(uint8_t shape, double ph, double vpp_V, double ofs_V) {
  double x;
  switch (shape) {
    case 0: x = w_sine(ph);     break;
    case 1: x = w_square(ph);   break;
    case 2: x = w_triangle(ph); break;
    case 3: x = w_sinc(ph);     break;
    default: x = 0.0;           break;
  }
  double v = ofs_V + 0.5 * vpp_V * x;
  return v_to_code(v);
}

// ---- progress helper (25/50/75/done) ----
struct Prog {
  uint32_t m1, m2, m3;
  bool p1, p2, p3;
  bool enable_milestones;
};

static inline Prog prog_init(uint32_t total) {
  Prog p;
  p.m1 = total / 4u;
  p.m2 = total / 2u;
  p.m3 = (total * 3u) / 4u;
  p.p1 = p.p2 = p.p3 = false;

  // If the transfer is tiny, milestones are noise; print only one final line.
  p.enable_milestones = (total >= 64u);
  return p;
}

static inline void prog_maybe_print(Prog& p, uint32_t written, uint32_t total) {
  if (!p.enable_milestones) return;

  if (!p.p1 && written >= p.m1 && p.m1 > 0) {
    Serial.printf("[TX] %lu/%lu sent\n", (unsigned long)written, (unsigned long)total);
    p.p1 = true;
    return; // IMPORTANT: only 1 milestone per call
  }
  if (!p.p2 && written >= p.m2 && p.m2 > 0) {
    Serial.printf("[TX] %lu/%lu sent\n", (unsigned long)written, (unsigned long)total);
    p.p2 = true;
    return;
  }
  if (!p.p3 && written >= p.m3 && p.m3 > 0) {
    Serial.printf("[TX] %lu/%lu sent\n", (unsigned long)written, (unsigned long)total);
    p.p3 = true;
    return;
  }
}

static inline void prog_done_line(Prog& p, uint32_t total) {
  Serial.printf("[TX] %lu/%lu sent (done)\n", (unsigned long)total, (unsigned long)total);
}

// ---- FPGA-guy register algorithm (exact constants) ----
// Computes width and programs reset/ftw accordingly.
static void program_regs_like_fpga_guy(uint8_t nco_index, uint32_t freq_mHz, uint32_t& out_width) {
  if (freq_mHz <= 15258u) {                // 15.258 Hz
    out_width = 65535u;
    fpga_set_reset_width(nco_index, 65535u);
    uint32_t tw = (uint32_t)((double)freq_mHz * 1407.37488);
    fpga_set_ftw(nco_index, tw);
  } else {
    uint32_t w = (freq_mHz == 0) ? 65535u : (uint32_t)(1000000000ULL / (uint64_t)freq_mHz);
    if (w == 0) w = 1;
    if (w > 65535u) w = 65535u;
    out_width = w;
    fpga_set_reset_width(nco_index, (uint16_t)w);
    fpga_set_ftw(nco_index, 21474836u);    // 0.01*(2^31)
  }
}

// Square special-case like FPGA-guy:
// reset=1, ftw=freq*0.042949673, only 2 samples.
// Phase approximated as 0° or 180° by swapping top/bot.
static void program_square_like_fpga_guy(uint8_t sram_index,
                                        uint8_t nco_index,
                                        uint32_t freq_mHz,
                                        double vpp_V,
                                        double ofs_V,
                                        int16_t phase_deg)
{
  fpga_set_reset_width(nco_index, 1);

  uint32_t stw = (uint32_t)((double)freq_mHz * 0.042949673);
  fpga_set_ftw(nco_index, stw);

  uint16_t top = sample_code(1, 0.0, vpp_V, ofs_V);   // +1
  uint16_t bot = sample_code(1, 0.5, vpp_V, ofs_V);   // -1

  int ph = (int)phase_deg % 360;
  if (ph < 0) ph += 360;
  bool invert = (ph >= 180);

  fpga_write_sram(sram_index, 0, invert ? bot : top);
  fpga_write_sram(sram_index, 1, invert ? top : bot);
}

// Stream LUT (width samples) with amp/offset/phase
static void send_lut_stream(uint8_t sram_index,
                            uint8_t shape,
                            uint32_t width,
                            double phase_off,
                            double vpp_V,
                            double ofs_V)
{
  if (width == 0) return;
  if (width > LUT_SIZE_MAX) width = LUT_SIZE_MAX;

  const uint32_t CHUNK = 1024;
  Prog prog = prog_init(width);

  for (uint32_t base = 0; base < width; base += CHUNK) {
    uint32_t end = base + CHUNK;
    if (end > width) end = width;

    for (uint32_t addr = base; addr < end; ++addr) {
      double ph = fmod((addr / (double)width) + phase_off, 1.0);
      uint16_t data = sample_code(shape, ph, vpp_V, ofs_V);
      fpga_write_sram(sram_index, (uint16_t)addr, data);
    }

    prog_maybe_print(prog, end, width);
    delay(0);
  }

  prog_done_line(prog, width);
}

// ---- ARB resampling: 1024 -> width ----
// Linear interpolation on the original 1024 points.
// IMPORTANT: We only write `width` samples so ARB matches STD behavior at high frequency.
static inline uint16_t arb_sample_at(const uint16_t* in1024, uint32_t width, uint32_t out_i) {
  if (width <= 1) return in1024[0];

  // Map out_i [0..width-1] -> input index [0..1023] in Q16
  uint64_t numer = (uint64_t)out_i * (ARB_IN_SAMPLES - 1) * 65536ULL;
  uint64_t denom = (uint64_t)(width - 1);
  uint32_t t_q16 = (uint32_t)(numer / denom);

  uint32_t k    = t_q16 >> 16;         // 0..1023
  uint32_t frac = t_q16 & 0xFFFFu;     // 0..65535

  uint16_t a = in1024[k];
  uint16_t b = (k < (ARB_IN_SAMPLES - 1)) ? in1024[k + 1] : in1024[ARB_IN_SAMPLES - 1];

  // lerp in Q16
  uint32_t wa = 65535u - frac;
  uint32_t wb = frac;
  uint32_t acc = (uint32_t)a * wa + (uint32_t)b * wb;
  return (uint16_t)((acc + 32767u) / 65535u);
}

static void send_arb_width_stream(uint8_t sram_index, const uint16_t* in1024, uint32_t width) {
  if (width == 0) return;
  if (width > LUT_SIZE_MAX) width = LUT_SIZE_MAX;

  const uint32_t CHUNK = 1024;
  Prog prog = prog_init(width);

  for (uint32_t base = 0; base < width; base += CHUNK) {
    uint32_t end = base + CHUNK;
    if (end > width) end = width;

    for (uint32_t i = base; i < end; ++i) {
      uint16_t y = arb_sample_at(in1024, width, i);
      fpga_write_sram(sram_index, (uint16_t)i, y);
    }

    prog_maybe_print(prog, end, width);
    delay(0);
  }

  prog_done_line(prog, width);
}

// ---- Public entry points called by ble.cpp ----
extern "C" void wavegen_build_std_lut(const StdParams& p) {
  if (tx_busy) { Serial.println("[TX] busy"); return; }
  tx_busy = true;

  uint32_t t0 = millis();

  const uint8_t sram_index = (p.channel & 1) ? 1 : 0;
  const uint8_t nco_index  = (p.channel & 1) ? 1 : 0;

  const double vpp_V = (double)p.amp_mVpp / 1000.0;
  const double ofs_V = (double)p.offset_mV / 1000.0;
  double phase_off = (double)p.phase_deg / 360.0;
  phase_off = phase_off - floor(phase_off);

  Serial.printf("[STD] ch=%s shape=%u freq=%lu mHz vpp=%.3fV ofs=%.3fV ph=%ddeg\n",
                chan_name(p.channel),
                (unsigned)p.shape,
                (unsigned long)p.freq_mHz,
                vpp_V, ofs_V, (int)p.phase_deg);

  Serial.printf("[TX] STD start\n");

  if (p.shape == 1) {
    Serial.printf("[TX] square mode (2 samples)\n");
    program_square_like_fpga_guy(sram_index, nco_index, p.freq_mHz, vpp_V, ofs_V, p.phase_deg);
    fpga_run();
    Serial.printf("[TX] complete in %.3f s\n", (millis() - t0) / 1000.0);
    delay(100);
    tx_busy = false;
    return;
  }

  uint32_t width = 0;
  program_regs_like_fpga_guy(nco_index, p.freq_mHz, width);

  Serial.printf("[TX] LUT width=%lu\n", (unsigned long)width);
  send_lut_stream(sram_index, p.shape, width, phase_off, vpp_V, ofs_V);

  fpga_run();

  Serial.printf("[TX] complete in %.3f s\n", (millis() - t0) / 1000.0);

  delay(100);
  tx_busy = false;
}

extern "C" void wavegen_build_arb_lut(const uint16_t* in1024, uint8_t channel, uint32_t freq_mHz) {
  if (tx_busy) { Serial.println("[TX] busy"); return; }
  tx_busy = true;

  uint32_t t0 = millis();

  const uint8_t sram_index = (channel & 1) ? 1 : 0;
  const uint8_t nco_index  = (channel & 1) ? 1 : 0;

  Serial.printf("[ARB] ch=%s freq=%lu mHz\n", chan_name(channel), (unsigned long)freq_mHz);
  Serial.printf("[TX] ARB start\n");

  // Program regs and compute width exactly like FPGA-guy
  uint32_t width = 0;
  program_regs_like_fpga_guy(nco_index, freq_mHz, width);

  Serial.printf("[TX] ARB width=%lu\n", (unsigned long)width);

  // NEW: write only width samples (ARB matches STD at high frequency)
  send_arb_width_stream(sram_index, in1024, width);

  fpga_run();

  Serial.printf("[TX] complete in %.3f s\n", (millis() - t0) / 1000.0);

  delay(100);
  tx_busy = false;
}
