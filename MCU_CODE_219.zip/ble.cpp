// src/ble.cpp — Nordic UART BLE with STD (legacy) + ARB state machine,
// FIXED: do NOT run 64k SPI transfers inside BLE callback (BTC_TASK).
// We enqueue work and execute it in a separate FreeRTOS task to avoid WDT resets.
//
// STD payload (legacy, unchanged):
//   'S', shape(1), freq_mHz(u32), amp_mVpp(u32), offset_mV(s32), phase_deg(s16), channel(1)
//
// ARB protocol (unchanged):
//   META: 'A' + channel(1) + freq_mHz(u32)
//   DATA: 'D' + count(u16 LE) + count*u16 LE samples
//   END : 'Z'  (commit if exactly 1024 samples buffered)

#include <Arduino.h>
#include <BLEDevice.h>
#include <BLEServer.h>
#include <BLEUtils.h>
#include <BLE2902.h>
#include <string.h>

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "freertos/queue.h"

// ---------- Nordic UART UUIDs ----------
static const char* SVC_UUID = "6e400001-b5a3-f393-e0a9-e50e24dcca9e";
static const char* RX_UUID  = "6e400002-b5a3-f393-e0a9-e50e24dcca9e"; // write
static const char* TX_UUID  = "6e400003-b5a3-f393-e0a9-e50e24dcca9e"; // notify

// ---------- External wavegen API ----------
extern "C" {
  // IMPORTANT: matches wavegen.cpp / legacy STD layout.
  struct StdParams {
    uint8_t  shape;       // 0=sine,1=square,2=triangle,3=sinc
    uint32_t freq_mHz;
    uint32_t amp_mVpp;
    int32_t  offset_mV;
    int16_t  phase_deg;
    uint8_t  channel;     // 0=A,1=B
  };

  void wavegen_build_std_lut(const StdParams& p);
  void wavegen_build_arb_lut(const uint16_t* in1024, uint8_t channel, uint32_t freq_mHz);
}

static inline const char* chan_name(uint8_t ch){ return (ch & 1) ? "B" : "A"; }

// ---------- BLE globals ----------
static BLEServer*         g_srv = nullptr;
static BLECharacteristic* g_rx  = nullptr;
static BLECharacteristic* g_tx  = nullptr;
static bool g_deviceConnected = false;

// ---------- Work queue + worker task ----------
enum JobType : uint8_t { JOB_STD = 1, JOB_ARB = 2 };

struct Job {
  JobType type;
  StdParams std;
  uint16_t* arb_ptr;      // malloc'd 1024 samples for ARB (freed by worker)
  uint8_t  arb_channel;
  uint32_t arb_freq_mHz;
};

static QueueHandle_t g_job_q = nullptr;
static TaskHandle_t  g_worker_task = nullptr;

static bool enqueue_job(const Job& j) {
  if (!g_job_q) return false;
  if (xQueueSend(g_job_q, &j, 0) != pdTRUE) {
    Serial.println("[JOB] queue full, drop");
    return false;
  }
  return true;
}

static void worker_task(void*) {
  Serial.printf("[JOB] worker started on core %d\n", (int)xPortGetCoreID());

  Job j{};
  while (true) {
    if (xQueueReceive(g_job_q, &j, portMAX_DELAY) == pdTRUE) {
      if (j.type == JOB_STD) {
        wavegen_build_std_lut(j.std);
      } else if (j.type == JOB_ARB) {
        wavegen_build_arb_lut(j.arb_ptr, j.arb_channel, j.arb_freq_mHz);
        if (j.arb_ptr) {
          free(j.arb_ptr);
          j.arb_ptr = nullptr;
        }
      }
    }
    // yield just in case
    vTaskDelay(1);
  }
}

// ---------- ARB state ----------
static uint16_t arb_buf[1024];
static uint16_t arb_count = 0;
static uint8_t  arb_channel = 0;
static uint32_t arb_freq_mHz = 0;
static bool     arb_meta_seen = false;

static void arb_reset_state() {
  arb_count = 0;
  arb_channel = 0;
  arb_freq_mHz = 0;
  arb_meta_seen = false;
}

static void arb_commit_if_ready() {
  if (!arb_meta_seen) { Serial.println("[ARB] END without META"); return; }
  if (arb_count != 1024) {
    Serial.printf("[ARB] END but count=%u (need 1024)\n", arb_count);
    return;
  }

  // Copy samples to heap so BLE can keep receiving without buffer corruption.
  uint16_t* copy = (uint16_t*)malloc(1024 * sizeof(uint16_t));
  if (!copy) {
    Serial.println("[ARB] malloc failed, drop commit");
    arb_reset_state();
    return;
  }
  memcpy(copy, arb_buf, 1024 * sizeof(uint16_t));

  Serial.printf("[ARB] COMMIT queued ch=%s freq=%lu mHz, samples=1024\n",
                chan_name(arb_channel), (unsigned long)arb_freq_mHz);

  Job j{};
  j.type = JOB_ARB;
  j.arb_ptr = copy;
  j.arb_channel = arb_channel;
  j.arb_freq_mHz = arb_freq_mHz;

  if (!enqueue_job(j)) {
    free(copy);
    Serial.println("[ARB] queue full, commit dropped");
  }

  arb_reset_state();
}

// ---------- Server callbacks ----------
class ServerCallbacks : public BLEServerCallbacks {
  void onConnect(BLEServer*) override {
    g_deviceConnected = true;
    Serial.println("[BLE] Connected");
  }
  void onDisconnect(BLEServer*) override {
    g_deviceConnected = false;
    Serial.println("[BLE] Disconnected");
    arb_reset_state();
    BLEDevice::startAdvertising();
  }
};

// ---------- RX handler ----------
class RxCallbacks : public BLECharacteristicCallbacks {
  static uint32_t rd_u32_le(const uint8_t* p){
    return (uint32_t)p[0] | ((uint32_t)p[1]<<8) | ((uint32_t)p[2]<<16) | ((uint32_t)p[3]<<24);
  }
  static uint16_t rd_u16_le(const uint8_t* p){
    return (uint16_t)p[0] | ((uint16_t)p[1]<<8);
  }

  void onWrite(BLECharacteristic* c) override {
    std::string v = c->getValue();
    const uint8_t* d = (const uint8_t*)v.data();
    size_t n = v.size();
    if (n == 0) return;

    // ----- STD (unchanged parsing) -----
    // 'S' + shape(1) + freq_mHz(4) + amp_mVpp(4) + offset_mV(4) + phase_deg(2) + channel(1)
    if (d[0] == 'S') {
      if (n < 17) { Serial.printf("[STD] bad len=%u\n",(unsigned)n); return; }

      StdParams p{};
      size_t i = 1;
      p.shape = d[i++];

      memcpy(&p.freq_mHz,  d+i, 4); i+=4;
      memcpy(&p.amp_mVpp,  d+i, 4); i+=4;
      memcpy(&p.offset_mV, d+i, 4); i+=4;
      memcpy(&p.phase_deg, d+i, 2); i+=2;

      p.channel = d[i++];

      // Enqueue instead of running immediately (prevents BTC_TASK WDT).
      Job j{};
      j.type = JOB_STD;
      j.std = p;

      if (!enqueue_job(j)) {
        Serial.println("[STD] queue full, dropped");
      }
      return;
    }

    // ----- ARB META -----
    // 'A' + channel(1) + freq_mHz(4)
    if (d[0] == 'A') {
      if (n < 1+1+4) { Serial.printf("[ARB] META bad len=%u\n",(unsigned)n); return; }
      arb_reset_state();
      arb_channel   = d[1];
      arb_freq_mHz  = rd_u32_le(&d[2]);
      arb_meta_seen = true;
      Serial.printf("[ARB] META ch=%s freq=%lu mHz\n", chan_name(arb_channel), (unsigned long)arb_freq_mHz);
      return;
    }

    // ----- ARB DATA -----
    // 'D' + count(u16 LE) + count*u16 LE samples
    if (d[0] == 'D') {
      if (!arb_meta_seen) { Serial.println("[ARB] DATA before META"); return; }
      if (n < 3) { Serial.printf("[ARB] DATA too short len=%u\n",(unsigned)n); return; }
      uint16_t cnt = rd_u16_le(&d[1]);
      if (n != (size_t)(3 + 2*cnt)) {
        Serial.printf("[ARB] DATA len=%u mism cnt=%u\n",(unsigned)n, cnt);
        return;
      }
      if (arb_count + cnt > 1024) {
        Serial.printf("[ARB] DATA overflow: have=%u add=%u\n", arb_count, cnt);
        return;
      }
      const uint8_t* p = &d[3];
      for (uint16_t i=0;i<cnt;i++,p+=2) {
        arb_buf[arb_count++] = rd_u16_le(p);
      }
      if ((arb_count % 120) == 0 || arb_count == 1024) {
        Serial.printf("[ARB] DATA ok, total=%u\n", arb_count);
      }
      return;
    }

    // ----- ARB END -----
    if (d[0] == 'Z') {
      arb_commit_if_ready();
      return;
    }

    Serial.printf("[BLE] Unknown payload len=%u (op=0x%02X)\n", (unsigned)n, d[0]);
  }
};

void ble_setup(){
  BLEDevice::init("ESP32-JOE");
  g_srv = BLEDevice::createServer();
  g_srv->setCallbacks(new ServerCallbacks());

  BLEService* svc = g_srv->createService(SVC_UUID);
  g_rx = svc->createCharacteristic(RX_UUID, BLECharacteristic::PROPERTY_WRITE);
  g_tx = svc->createCharacteristic(TX_UUID, BLECharacteristic::PROPERTY_NOTIFY);
  g_tx->addDescriptor(new BLE2902());

  g_rx->setCallbacks(new RxCallbacks());
  svc->start();

  BLEAdvertising* adv = BLEDevice::getAdvertising();
  adv->addServiceUUID(SVC_UUID);
  adv->setScanResponse(true);
  adv->setMinPreferred(0x06);
  adv->setMinPreferred(0x12);
  BLEDevice::startAdvertising();

  // Create job queue + worker task.
  if (!g_job_q) {
    g_job_q = xQueueCreate(2, sizeof(Job)); // small queue; adjust if you want
  }
  if (g_job_q && !g_worker_task) {
    // Run worker on core 1 so it doesn't block BLE/BTC_TASK on core 0.
    xTaskCreatePinnedToCore(worker_task, "wavegen_worker", 8192, nullptr, 2, &g_worker_task, 1);
  }

  Serial.println("[BLE] Advertising as ESP32-JOE");
}

void ble_loop_pump(){
  // Keep Arduino loop alive; BLE runs mostly in its own tasks.
  delay(2);
}
