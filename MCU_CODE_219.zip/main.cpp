#include <Arduino.h>

// BLE
void ble_setup();
void ble_loop_pump();

// SPI driver
extern "C" {
  void fpga_spi_setup(int sck, int mosi, int cs, unsigned hz);
  void fpga_reset_setup(int rstn_pin);
  void fpga_reset_pulse();
}

void setup() {
  Serial.begin(115200);
  while (!Serial && millis() < 2000) { delay(10); }
  Serial.println("[BOOT] ESP32-S3 Sender");

  // Your pins
  const int PIN_SCK  = 11;
  const int PIN_MOSI = 9;
  const int PIN_CS   = 12;

  // Write-only: repurpose unused MISO GPIO as FPGA rstn
  const int PIN_MISO_UNUSED_AS_RSTN = 10;

  fpga_spi_setup(PIN_SCK, PIN_MOSI, PIN_CS, 1000000);

  // Exact reset pulse like his setup()
  fpga_reset_setup(PIN_MISO_UNUSED_AS_RSTN);
  fpga_reset_pulse();

  ble_setup();
  Serial.println("[INFO] BLE ready");
}

void loop() {
  ble_loop_pump();
}
